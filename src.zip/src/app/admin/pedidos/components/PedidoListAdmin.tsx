'use client';

import { useState, useEffect, useMemo } from 'react';
import { useGetPedidosAdm } from '@/src/hooks/pedido/useGetPedidosAdm';
import { Pagination } from '@/src/components/layout/Pagination';
import { PedidoCardAdmin } from './PedidoCardAdmin';

const PAGE_SIZE = 12;

const STATUS_OPTIONS = [
  { value: '', label: 'Todos os status' },
  { value: 'pendente',   label: 'Pendente' },
  { value: 'confirmado', label: 'Confirmado' },
  { value: 'enviado',    label: 'Enviado' },
  { value: 'entregue',   label: 'Entregue' },
  { value: 'cancelado',  label: 'Cancelado' },
];

export const PedidoListAdmin = () => {
  const { execute, pedidos, loading, error } = useGetPedidosAdm();
  const [statusFilter, setStatusFilter] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => { execute(); }, []);

  const filtered = useMemo(() => {
    if (!statusFilter) return pedidos;
    return pedidos.filter(
      (p) => (p.status ?? 'pendente').toLowerCase() === statusFilter
    );
  }, [pedidos, statusFilter]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE
  );

  const handleStatusChange = (value: string) => {
    setStatusFilter(value);
    setCurrentPage(1);
  };

  return (
    <div className="container mx-auto pt-5 pb-5 px-10">

      {/* Cabeçalho */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Pedidos</h2>
          <p className="text-sm text-gray-400 mt-0.5">
            {loading ? '...' : `${filtered.length} pedido(s) encontrado(s)`}
          </p>
        </div>

        {/* Dropdown de filtro */}
        <div className="relative">
          <select
            value={statusFilter}
            onChange={(e) => handleStatusChange(e.target.value)}
            className="
              appearance-none cursor-pointer
              bg-white border border-gray-200 hover:border-gray-300
              text-gray-700 text-sm font-medium
              pl-4 pr-9 py-2.5
              rounded-full shadow-sm
              outline-none focus:ring-2 focus:ring-purple-200 focus:border-purple-400
              transition-all duration-150
            "
          >
            {STATUS_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
          <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </span>
        </div>
      </div>

      {/* Estados */}
      {loading && (
        <p className="text-center font-medium text-gray-400 animate-pulse">
          Carregando pedidos...
        </p>
      )}

      {error && (
        <p className="text-center font-medium text-red-500">{error}</p>
      )}

      {!loading && !error && paginated.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 gap-3 text-gray-400">
          <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
          </svg>
          <p className="text-sm font-medium">Nenhum pedido encontrado.</p>
        </div>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {paginated.map((pedido) => (
          <PedidoCardAdmin
            key={pedido.id_pedido}
            pedido={pedido}
            onStatusUpdated={execute}
          />
        ))}
      </div>

      <Pagination
        totalPages={totalPages}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
      />
    </div>
  );
};